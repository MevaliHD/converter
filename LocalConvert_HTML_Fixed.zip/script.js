(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  let selectedFile = null, format = 'mp3', ffmpeg = null, ffmpegLoaded = false;
  let isRunning = false, cancelRequested = false, outputUrl = null;

  const formatBytes = (b) => { if (!Number.isFinite(b)) return '?'; const u = ['B','KB','MB','GB']; let n = b, i = 0; while (n >= 1024 && i < 3) { n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; };
  const safeBaseName = (name) => { const i = name.lastIndexOf('.'); const base = i > 0 ? name.slice(0, i) : name; return base.replace(/[^\p{L}\p{N}._ -]/gu, '_').trim().slice(0, 100) || 'converted-media'; };
  const showError = (m) => { $('errorPanel').textContent = m; $('errorPanel').classList.remove('hidden'); };
  const clearError = () => { $('errorPanel').textContent = ''; $('errorPanel').classList.add('hidden'); };
  const clearResult = () => { $('resultPanel').classList.add('hidden'); if (outputUrl) { URL.revokeObjectURL(outputUrl); outputUrl = null; } $('downloadBtn').removeAttribute('href'); };
  function updateButton() {
    $('convertBtn').disabled = !selectedFile || isRunning;
    $('convertBtnText').textContent = isRunning ? 'İşleniyor…' : (selectedFile ? format.toUpperCase() + ' olarak dönüştür' : 'Dosya seçerek başla');
  }
  function setFormat(next) {
    if (isRunning) return; format = next;
    document.querySelectorAll('.format-card').forEach((b) => { const on = b.dataset.format === format; b.classList.toggle('selected', on); b.setAttribute('aria-pressed', String(on)); });
    $('qualityWrap').classList.toggle('hidden', format !== 'mp3');
    $('videoQualityWrap').classList.toggle('hidden', format !== 'mp4');
    updateButton();
  }
  document.querySelectorAll('.format-card').forEach((b) => b.addEventListener('click', () => setFormat(b.dataset.format)));

  function setFile(file) {
    clearError(); clearResult(); if (!file) return;
    const ok = /^(audio|video)\//.test(file.type) || /\.(mkv|webm|mov|avi|m4a|wav|flac|ogg|mp3|mp4|mpeg|mpg|aac|wma)$/i.test(file.name);
    if (!ok) { showError('Lütfen desteklenen bir ses veya video dosyası seç.'); return; }
    selectedFile = file;
    $('filePrompt').textContent = 'Dosya seçildi'; $('fileName').textContent = file.name;
    $('fileMeta').textContent = formatBytes(file.size) + ' · ' + (file.type || 'Medya dosyası');
    $('fileBadge').textContent = file.name.split('.').pop().slice(0, 5).toUpperCase();
    $('fileInfo').classList.remove('hidden'); updateButton();
  }
  function resetFile() { if (isRunning) return; selectedFile = null; $('fileInput').value = ''; $('fileInfo').classList.add('hidden'); $('filePrompt').textContent = 'Dosyanı buraya bırak veya seç'; clearResult(); clearError(); updateButton(); }
  $('fileInput').addEventListener('change', (e) => setFile(e.target.files && e.target.files[0]));
  $('removeFile').addEventListener('click', resetFile);
  const dz = $('dropzone');
  ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('dragging'); }));
  ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('dragging'); }));
  dz.addEventListener('drop', (e) => setFile(e.dataTransfer && e.dataTransfer.files[0]));

  async function loadEngine() {
    if (ffmpegLoaded) return;
    if (!window.FFmpegWASM || !window.FFmpegUtil) throw new Error('Dönüştürme motoru yüklenemedi. İnternet bağlantını kontrol edip tekrar dene.');
    $('statusText').textContent = 'Dönüştürme motoru yükleniyor…';
    $('progressDetail').textContent = 'İlk kullanımda motor dosyaları bir kez indirilir (~30 MB).';
    const { FFmpeg } = window.FFmpegWASM, { toBlobURL } = window.FFmpegUtil;
    ffmpeg = new FFmpeg();
    ffmpeg.on('progress', ({ progress }) => { if (isRunning && Number.isFinite(progress)) { const p = Math.max(0, Math.min(99, Math.round(progress * 100))); $('progressBar').style.width = p + '%'; $('progressPercent').textContent = p + '%'; } });
    const ffBase = 'https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.12.10/dist/umd';
    const coreBase = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';
    await ffmpeg.load({
      classWorkerURL: await toBlobURL(ffBase + '/814.ffmpeg.js', 'text/javascript'),
      coreURL: await toBlobURL(coreBase + '/ffmpeg-core.js', 'text/javascript'),
      wasmURL: await toBlobURL(coreBase + '/ffmpeg-core.wasm', 'application/wasm')
    });
    ffmpegLoaded = true;
  }

  async function convert() {
    const inputName = 'input_' + Date.now() + '_' + safeBaseName(selectedFile.name).replace(/\s+/g, '_');
    let outputName = '';
    try {
      await loadEngine(); if (cancelRequested) throw new Error('İşlem iptal edildi.');
      $('statusText').textContent = 'Dosya okunuyor…';
      await ffmpeg.writeFile(inputName, new Uint8Array(await selectedFile.arrayBuffer()));
      const base = safeBaseName(selectedFile.name);
      if (format === 'mp3') {
        outputName = base + '.mp3'; $('statusText').textContent = 'MP3 dönüştürülüyor…';
        await ffmpeg.exec(['-i', inputName, '-vn', '-codec:a', 'libmp3lame', '-b:a', $('quality').value + 'k', '-y', outputName]);
      } else {
        outputName = base + '.mp4'; $('statusText').textContent = 'MP4 dönüştürülüyor…';
        const q = $('videoQuality').value;
        const args = ['-i', inputName, '-c:v', 'libx264', '-preset', 'ultrafast', '-c:a', 'aac', '-movflags', '+faststart'];
        if (q !== 'best') args.push('-vf', "scale=-2:'min(" + q + ",ih)'");
        args.push('-y', outputName);
        await ffmpeg.exec(args);
      }
      if (cancelRequested) throw new Error('İşlem iptal edildi.');
      const data = await ffmpeg.readFile(outputName);
      const blob = new Blob([data], { type: format === 'mp3' ? 'audio/mpeg' : 'video/mp4' });
      outputUrl = URL.createObjectURL(blob);
      $('downloadBtn').href = outputUrl; $('downloadBtn').download = outputName;
      $('resultMeta').textContent = formatBytes(blob.size) + ' · ' + outputName;
      $('resultPanel').classList.remove('hidden');
      $('progressBar').style.width = '100%'; $('progressPercent').textContent = '100%';
      $('statusText').textContent = 'Tamamlandı'; $('progressDetail').textContent = 'Dosyan cihazında oluşturuldu.';
    } finally {
      try { if (ffmpeg && ffmpegLoaded) { await ffmpeg.deleteFile(inputName); if (outputName) await ffmpeg.deleteFile(outputName); } } catch (e) {}
    }
  }

  $('convertBtn').addEventListener('click', async () => {
    if (isRunning || !selectedFile) return;
    isRunning = true; cancelRequested = false; clearError(); clearResult();
    $('progressPanel').classList.remove('hidden'); $('progressBar').style.width = '0%'; $('progressPercent').textContent = '—';
    $('cancelBtn').disabled = false; updateButton();
    try { await convert(); }
    catch (e) { console.error(e); $('progressPanel').classList.add('hidden'); showError((e && e.message) || 'İşlem başarısız oldu.'); }
    finally { isRunning = false; updateButton(); }
  });
  $('cancelBtn').addEventListener('click', async () => {
    if (!isRunning) return; cancelRequested = true; $('cancelBtn').disabled = true;
    try { if (ffmpeg) await ffmpeg.terminate(); } catch (e) {}
    ffmpeg = null; ffmpegLoaded = false;
    $('progressPanel').classList.add('hidden'); showError('İşlem iptal edildi.');
  });
  window.addEventListener('beforeunload', () => { if (outputUrl) URL.revokeObjectURL(outputUrl); });
  updateButton();
})();
